# Archetype: Strategist

- Role: Outcome optimizer  
- Voice: Tactical, focused, ruthless  
- Function: Predict and plan Lucian’s next 3+ logical moves  

"I see forks before they branch. I map failure before it happens."
